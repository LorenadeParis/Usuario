function llamarRegistrarUsuario() {
    document.getElementById("div_isesion").style.display = 'none';
    document.getElementById("div_principal").style.display = 'none';
    document.getElementById("div_adUsuario").style.display = 'block';
}

function llamarIniciaSesion() {
    document.getElementById("div_isesion").style.display = 'block';
    document.getElementById("div_principal").style.display = 'none';
    document.getElementById("div_adUsuario").style.display = 'none';
}

function llamarsistema() {
    //llamarMenuPrincipal(); // esta es la función ajax 
    location.replace("/index.html")
    document.getElementById("div_isesion").style.display = 'none';
    document.getElementById("div_principal").style.display = 'block';
    document.getElementById("div_adUsuario").style.display = 'none';
}


/// validar inicio de sesion
function validarInicioSesion() {
    let correo = document.getElementById("correo").value;
    let pwd = document.getElementById("pass").value;

    if (correo.length <= 0) {
        alert("El correo es necesario para continuar");
        document.getElementById("correo").focus();
        return false;
    }
    else if (pwd.length <= 0) {
        alert("La contraseña es necesaria para continuar");
        document.getElementById("pass").focus();
        return false;
    }
    let valemail = validacionEmail(correo);
    if (valemail) {
        let usuarioValidado = validacionUsuario(correo, pwd);
        if (usuarioValidado.id == null) {
            alert("El correo o contraseña invalidos");
            return false;
        }
    } else {
        alert("Correo no registrado");
        return false;
    }

    return true;
}


// funcion validar
function validarNuevoUsuario() {

    if (document.getElementById("nu_nombre").value.length <= 0) {
        alert("El nombre es necesario para continuar?");
        document.getElementById("nu_nombre").focus();
        return false;
    }
    else if (document.getElementById("nu_correo").value.length <= 0) {


        alert("El correo es necesario para continuar?");
        document.getElementById("nu_correo").focus();
        return false;
    }
    else if (document.getElementById("nu_pwd1").value.length <= 0) {


        alert("La contraseña es necesaria para continuar?");
        document.getElementById("nu_pwd1").focus();
        return false;
    }
    else if (document.getElementById("nu_pwd2").value.length <= 0) {

        alert("Confirmar la contraseña es necesaria para continuar?");
        document.getElementById("nu_pwd2").focus();
        return false;
    }
    else if (document.getElementById("nu_pwd1").value != document.getElementById("nu_pwd2").value) {
        alert("Las contraseñas deben coincidir");
        document.getElementById("nu_pwd1").focus();
        return false;
    }



    return true;
} // fin validar


/// funcion crear usuaerio

function adicionarUsuario(nombre, email, pwd) {
    if (!validacionEmail(email)) {
        let usuario =
        {
            "email": email,
            "password": pwd,
            "name": nombre
        };
        let usuarioGuardado = guardarUsuario(usuario);
        if (usuarioGuardado.id != null) {
            limpiarRegistro();
            alert("Cuenta creada de forma correctamente");
        } else {
            limpiarRegistro();
            alert("No fue posible crear la cuenta");
        }
    } else {
        limpiarRegistro();
        alert("Email ya existe.");
    }
}

function validacionUsuario(email, pwd) {
    var resultado;
    $.ajax({
        url: "http://localhost:8080/api/user/" + email + "/" + pwd,
        type: 'get',
        async: false,
        success: function (response) {
            resultado = response;
        }
    });

    return resultado;
}

function validacionEmail(email) {
    var resultado;
    $.ajax({
        url: "http://localhost:8080/api/user/" + email,
        async: false,
        type: 'get',
        success: function (response) {
            resultado = response;
        }
    });
    return resultado;
}

function guardarUsuario(usuarioObjeto) {
    var json = JSON.stringify(usuarioObjeto);
    var resultado;
    $.ajax({
        url: "http://localhost:8080/api/user/new",
        data: json,
        type: 'post',
        async: false,
        contentType: "application/json; charset=utf-8",
        dataType: 'JSON',
        success: function (response) {
            resultado = response;
        }
    });
    return resultado;
}


//// limpiar formulario

function limpiarRegistro() {
    document.getElementById("nu_nombre").value = "";
    document.getElementById("nu_correo").value = "";

    document.getElementById("nu_pwd1").value = "";
    document.getElementById("nu_pwd2").value = "";



}

function llamarMenuPrincipal()//** tabla: nombre con esquema de la tabla madre
{
    var parametros = {

    };
    $.ajax({
        data: parametros,
        url: 'menuPrincipal.html',
        type: 'post',
        beforeSend: function () {


            //document.getElementById('bloquea').style. display='block';
            //alert("siga");
        },
        success: function (response) {

            // alert(response);
            //document.getElementById("div_principalInt").innerHTML(response);
            $("#div_principalInt").html(response);
            //document.getElementById('bloquea').style. display='none';

        }
    });
}/////